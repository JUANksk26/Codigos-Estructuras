public class ShellSortInt {

    static long iteraciones   = 0;
    static long comparaciones = 0;
    static long intercambios  = 0;

    public static void shellSort(int[] arr) {
        int n = arr.length;
        int gap = n / 2;
        while (gap > 0) {
            iteraciones++;
            for (int i = gap; i < n; i++) {
                int temp = arr[i];
                int j = i;
                while (j >= gap) {
                    comparaciones++;
                    if (arr[j - gap] > temp) {
                        intercambios++;
                        arr[j] = arr[j - gap];
                        j -= gap;
                    } else {
                        break;
                    }
                }
                arr[j] = temp;
            }
            gap /= 2;
        }
    }

    public static void main(String[] args) {
        int[] arr = {64, 3, 42, 17, 99, 8, 55, 23, 76, 11, 88, 34, 5};

        Runtime runtime = Runtime.getRuntime();
        runtime.gc();
        long memAntes = runtime.totalMemory() - runtime.freeMemory();
        long tiempoInicio = System.nanoTime();

        shellSort(arr);

        long tiempoFin = System.nanoTime();
        long memDespues = runtime.totalMemory() - runtime.freeMemory();

        System.out.println("=== SHELL SORT (int) ===");
        System.out.printf("Tiempo de ejecución : %,d ns (%.4f ms)%n",
                (tiempoFin - tiempoInicio), (tiempoFin - tiempoInicio) / 1_000_000.0);
        System.out.printf("Memoria usada       : %,d bytes%n", Math.max(0, memDespues - memAntes));
        System.out.printf("Iteraciones         : %,d%n", iteraciones);
        System.out.printf("Comparaciones       : %,d%n", comparaciones);
        System.out.printf("Intercambios        : %,d%n", intercambios);
    }
}
