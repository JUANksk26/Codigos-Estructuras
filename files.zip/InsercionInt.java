public class InsercionInt {

    static long iteraciones   = 0;
    static long comparaciones = 0;
    static long intercambios  = 0;

    public static void insercion(int[] arr) {
        int n = arr.length;
        for (int i = 1; i < n; i++) {
            iteraciones++;
            int key = arr[i];
            int j = i - 1;
            while (j >= 0) {
                comparaciones++;
                if (arr[j] > key) {
                    intercambios++;
                    arr[j + 1] = arr[j];
                    j--;
                } else {
                    break;
                }
            }
            arr[j + 1] = key;
        }
    }

    public static void main(String[] args) {
        int[] arr = {64, 3, 42, 17, 99, 8, 55, 23, 76, 11, 88, 34, 5};

        Runtime runtime = Runtime.getRuntime();
        runtime.gc();
        long memAntes = runtime.totalMemory() - runtime.freeMemory();
        long tiempoInicio = System.nanoTime();

        insercion(arr);

        long tiempoFin = System.nanoTime();
        long memDespues = runtime.totalMemory() - runtime.freeMemory();

        System.out.println("=== INSERCIÓN (int) ===");
        System.out.printf("Tiempo de ejecución : %,d ns (%.4f ms)%n",
                (tiempoFin - tiempoInicio), (tiempoFin - tiempoInicio) / 1_000_000.0);
        System.out.printf("Memoria usada       : %,d bytes%n", Math.max(0, memDespues - memAntes));
        System.out.printf("Iteraciones         : %,d%n", iteraciones);
        System.out.printf("Comparaciones       : %,d%n", comparaciones);
        System.out.printf("Intercambios        : %,d%n", intercambios);
    }
}
