public class QuickSortInt {

    static long iteraciones   = 0;
    static long comparaciones = 0;
    static long intercambios  = 0;

    public static void quickSort(int[] arr, int low, int high) {
        if (low < high) {
            iteraciones++;
            int pivotIndex = partition(arr, low, high);
            quickSort(arr, low, pivotIndex - 1);
            quickSort(arr, pivotIndex + 1, high);
        }
    }

    private static int partition(int[] arr, int low, int high) {
        int pivot = arr[high];
        int i = low - 1;
        for (int j = low; j < high; j++) {
            comparaciones++;
            if (arr[j] <= pivot) {
                i++;
                intercambios++;
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        intercambios++;
        int temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;
        return i + 1;
    }

    public static void main(String[] args) {
        int[] arr = {64, 3, 42, 17, 99, 8, 55, 23, 76, 11, 88, 34, 5};

        Runtime runtime = Runtime.getRuntime();
        runtime.gc();
        long memAntes = runtime.totalMemory() - runtime.freeMemory();
        long tiempoInicio = System.nanoTime();

        quickSort(arr, 0, arr.length - 1);

        long tiempoFin = System.nanoTime();
        long memDespues = runtime.totalMemory() - runtime.freeMemory();

        System.out.println("=== QUICK SORT (int) ===");
        System.out.printf("Tiempo de ejecución : %,d ns (%.4f ms)%n",
                (tiempoFin - tiempoInicio), (tiempoFin - tiempoInicio) / 1_000_000.0);
        System.out.printf("Memoria usada       : %,d bytes%n", Math.max(0, memDespues - memAntes));
        System.out.printf("Iteraciones         : %,d%n", iteraciones);
        System.out.printf("Comparaciones       : %,d%n", comparaciones);
        System.out.printf("Intercambios        : %,d%n", intercambios);
    }
}
