public class BurbujaSimpleInt {

    static long iteraciones   = 0;
    static long comparaciones = 0;
    static long intercambios  = 0;

    public static void burbujaSimple(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            iteraciones++;
            for (int j = 0; j < n - 1 - i; j++) {
                comparaciones++;
                if (arr[j] > arr[j + 1]) {
                    intercambios++;
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }

    public static void main(String[] args) {
        int[] arr = {64, 3, 42, 17, 99, 8, 55, 23, 76, 11, 88, 34, 5};

        Runtime runtime = Runtime.getRuntime();
        runtime.gc();
        long memAntes = runtime.totalMemory() - runtime.freeMemory();
        long tiempoInicio = System.nanoTime();

        burbujaSimple(arr);

        long tiempoFin = System.nanoTime();
        long memDespues = runtime.totalMemory() - runtime.freeMemory();

        System.out.println("=== BURBUJA SIMPLE (int) ===");
        System.out.printf("Tiempo de ejecución : %,d ns (%.4f ms)%n",
                (tiempoFin - tiempoInicio), (tiempoFin - tiempoInicio) / 1_000_000.0);
        System.out.printf("Memoria usada       : %,d bytes%n", Math.max(0, memDespues - memAntes));
        System.out.printf("Iteraciones         : %,d%n", iteraciones);
        System.out.printf("Comparaciones       : %,d%n", comparaciones);
        System.out.printf("Intercambios        : %,d%n", intercambios);
    }
}
